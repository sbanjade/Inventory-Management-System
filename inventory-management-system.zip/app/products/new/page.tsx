import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ProductForm } from "@/components/product-form"

export default function NewProductPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Add New Product" text="Add a new product to your inventory." />
      <div className="grid gap-8">
        <ProductForm />
      </div>
    </DashboardShell>
  )
}
