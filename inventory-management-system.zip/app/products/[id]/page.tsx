import { notFound } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ProductForm } from "@/components/product-form"
import { getProductById } from "@/lib/inventory-service"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const product = await getProductById(params.id)

  if (!product) {
    notFound()
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Edit Product" text="Update product information or stock levels." />
      <div className="grid gap-8">
        <ProductForm product={product} />
      </div>
    </DashboardShell>
  )
}
