import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ProductsTable } from "@/components/products-table"
import { Button } from "@/components/ui/button"
import { getProducts } from "@/lib/inventory-service"

export default async function ProductsPage() {
  const products = await getProducts()

  return (
    <DashboardShell>
      <DashboardHeader heading="Products" text="Manage your product inventory.">
        <Button asChild>
          <a href="/products/new">Add New Product</a>
        </Button>
      </DashboardHeader>
      <ProductsTable products={products} />
    </DashboardShell>
  )
}
