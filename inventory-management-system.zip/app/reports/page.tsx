import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ReportFilters } from "@/components/report-filters"
import { ReportTable } from "@/components/report-table"
import { getInventoryReports } from "@/lib/inventory-service"

export default async function ReportsPage() {
  const reports = await getInventoryReports()

  return (
    <DashboardShell>
      <DashboardHeader heading="Reports" text="Generate and view inventory reports." />
      <ReportFilters />
      <ReportTable reports={reports} />
    </DashboardShell>
  )
}
