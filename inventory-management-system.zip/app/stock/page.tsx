import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { StockUpdateTable } from "@/components/stock-update-table"
import { getProducts } from "@/lib/inventory-service"

export default async function StockPage() {
  const products = await getProducts()

  return (
    <DashboardShell>
      <DashboardHeader heading="Stock Management" text="Update stock levels for your products." />
      <StockUpdateTable products={products} />
    </DashboardShell>
  )
}
