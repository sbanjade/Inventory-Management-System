import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { InventoryOverview } from "@/components/inventory-overview"
import { RecentActivities } from "@/components/recent-activities"
import { LowStockAlert } from "@/components/low-stock-alert"
import { Button } from "@/components/ui/button"
import { getInventorySummary, getRecentActivities, getLowStockItems } from "@/lib/inventory-service"

export default async function DashboardPage() {
  // In a real app, you would check authentication here
  // const session = await getSession()
  // if (!session) redirect("/login")

  const inventorySummary = await getInventorySummary()
  const recentActivities = await getRecentActivities()
  const lowStockItems = await getLowStockItems()

  return (
    <DashboardShell>
      <DashboardHeader heading="Inventory Dashboard" text="Overview of your inventory management system.">
        <Button asChild>
          <a href="/products/new">Add New Product</a>
        </Button>
      </DashboardHeader>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <InventoryOverview data={inventorySummary} />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-4">
          <RecentActivities activities={recentActivities} />
        </div>
        <div className="col-span-3">
          <LowStockAlert items={lowStockItems} />
        </div>
      </div>
    </DashboardShell>
  )
}
