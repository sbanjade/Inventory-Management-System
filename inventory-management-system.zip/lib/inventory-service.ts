// This is a mock service that would be replaced with actual database calls
// in a real application

// Mock data
const mockProducts = [
  {
    id: "1",
    name: "Laptop",
    sku: "TECH-001",
    category: "electronics",
    description: "High-performance laptop with 16GB RAM",
    price: 1299.99,
    cost: 900,
    stock: 15,
    minStockLevel: 5,
  },
  {
    id: "2",
    name: "Smartphone",
    sku: "TECH-002",
    category: "electronics",
    description: "Latest smartphone model with 128GB storage",
    price: 899.99,
    cost: 600,
    stock: 25,
    minStockLevel: 10,
  },
  {
    id: "3",
    name: "Desk Chair",
    sku: "FURN-001",
    category: "furniture",
    description: "Ergonomic office chair",
    price: 249.99,
    cost: 150,
    stock: 8,
    minStockLevel: 5,
  },
  {
    id: "4",
    name: "Coffee Maker",
    sku: "APPL-001",
    category: "appliances",
    description: "Programmable coffee maker",
    price: 79.99,
    cost: 40,
    stock: 3,
    minStockLevel: 5,
  },
  {
    id: "5",
    name: "Wireless Headphones",
    sku: "TECH-003",
    category: "electronics",
    description: "Noise-cancelling wireless headphones",
    price: 199.99,
    cost: 120,
    stock: 12,
    minStockLevel: 8,
  },
]

const mockActivities = [
  {
    id: "1",
    type: "add",
    productName: "Laptop",
    quantity: 5,
    timestamp: "2023-04-15 09:30 AM",
    user: "Admin",
  },
  {
    id: "2",
    type: "update",
    productName: "Smartphone",
    quantity: 10,
    timestamp: "2023-04-14 02:15 PM",
    user: "John",
  },
  {
    id: "3",
    type: "remove",
    productName: "Desk Chair",
    quantity: 2,
    timestamp: "2023-04-14 11:45 AM",
    user: "Sarah",
  },
  {
    id: "4",
    type: "add",
    productName: "Coffee Maker",
    quantity: 8,
    timestamp: "2023-04-13 04:20 PM",
    user: "Admin",
  },
  {
    id: "5",
    type: "update",
    productName: "Wireless Headphones",
    quantity: 15,
    timestamp: "2023-04-13 10:10 AM",
    user: "John",
  },
]

const mockReports = [
  {
    id: "1",
    name: "Monthly Inventory Report - April 2023",
    type: "Inventory",
    date: "April 30, 2023",
    generatedBy: "Admin",
  },
  {
    id: "2",
    name: "Quarterly Sales Report - Q1 2023",
    type: "Sales",
    date: "March 31, 2023",
    generatedBy: "John",
  },
  {
    id: "3",
    name: "Low Stock Items Report",
    type: "Stock",
    date: "April 15, 2023",
    generatedBy: "Sarah",
  },
]

// Helper function to simulate async API calls
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Service functions
export async function getInventorySummary() {
  await delay(500)
  return {
    totalProducts: mockProducts.length,
    totalStock: mockProducts.reduce((sum, product) => sum + product.stock, 0),
    lowStockItems: mockProducts.filter((product) => product.stock <= product.minStockLevel).length,
    recentActivity: mockActivities.length,
  }
}

export async function getRecentActivities() {
  await delay(500)
  return mockActivities
}

export async function getLowStockItems() {
  await delay(500)
  return mockProducts
    .filter((product) => product.stock <= product.minStockLevel)
    .map(({ id, name, stock, minStockLevel }) => ({
      id,
      name,
      currentStock: stock,
      minStockLevel,
    }))
}

export async function getProducts() {
  await delay(500)
  return mockProducts
}

export async function getProductById(id: string) {
  await delay(500)
  return mockProducts.find((product) => product.id === id)
}

export async function createProduct(productData: any) {
  await delay(800)
  const newProduct = {
    id: String(mockProducts.length + 1),
    ...productData,
  }
  mockProducts.push(newProduct)
  return newProduct
}

export async function updateProduct(id: string, productData: any) {
  await delay(800)
  const index = mockProducts.findIndex((product) => product.id === id)
  if (index !== -1) {
    mockProducts[index] = { ...mockProducts[index], ...productData }
    return mockProducts[index]
  }
  throw new Error("Product not found")
}

export async function deleteProduct(id: string) {
  await delay(800)
  const index = mockProducts.findIndex((product) => product.id === id)
  if (index !== -1) {
    mockProducts.splice(index, 1)
    return true
  }
  throw new Error("Product not found")
}

export async function updateStock(id: string, quantity: number) {
  await delay(800)
  const index = mockProducts.findIndex((product) => product.id === id)
  if (index !== -1) {
    mockProducts[index].stock += quantity

    // Add to activities
    mockActivities.unshift({
      id: String(mockActivities.length + 1),
      type: quantity > 0 ? "add" : "remove",
      productName: mockProducts[index].name,
      quantity: Math.abs(quantity),
      timestamp: new Date().toLocaleString(),
      user: "Admin",
    })

    return mockProducts[index]
  }
  throw new Error("Product not found")
}

export async function getInventoryReports() {
  await delay(500)
  return mockReports
}
