"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/date-picker"

export function ReportFilters() {
  const [startDate, setStartDate] = useState<Date>()
  const [endDate, setEndDate] = useState<Date>()

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="grid gap-4 md:grid-cols-4">
          <div className="grid gap-2">
            <Select defaultValue="all">
              <SelectTrigger>
                <SelectValue placeholder="Report Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reports</SelectItem>
                <SelectItem value="inventory">Inventory Report</SelectItem>
                <SelectItem value="sales">Sales Report</SelectItem>
                <SelectItem value="stock">Stock Movement</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <DatePicker selected={startDate} onSelect={setStartDate} placeholder="Start Date" />
          </div>
          <div className="grid gap-2">
            <DatePicker selected={endDate} onSelect={setEndDate} placeholder="End Date" />
          </div>
          <div className="flex items-end">
            <Button className="w-full">Generate Report</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
