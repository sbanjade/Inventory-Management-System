"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { updateStock } from "@/lib/inventory-service"
import { toast } from "@/hooks/use-toast"

interface Product {
  id: string
  name: string
  sku: string
  stock: number
  minStockLevel: number
}

interface StockUpdateTableProps {
  products: Product[]
}

export function StockUpdateTable({ products: initialProducts }: StockUpdateTableProps) {
  const [products, setProducts] = useState(initialProducts)
  const [searchTerm, setSearchTerm] = useState("")
  const [stockUpdates, setStockUpdates] = useState<Record<string, number>>({})

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleStockChange = (id: string, value: string) => {
    const numValue = Number.parseInt(value, 10) || 0
    setStockUpdates({
      ...stockUpdates,
      [id]: numValue,
    })
  }

  const handleUpdateStock = async (id: string, currentStock: number) => {
    const updateValue = stockUpdates[id] || 0
    if (updateValue === 0) return

    try {
      await updateStock(id, updateValue)

      // Update local state
      const updatedProducts = products.map((product) => {
        if (product.id === id) {
          return {
            ...product,
            stock: currentStock + updateValue,
          }
        }
        return product
      })

      setProducts(updatedProducts)

      // Clear the input
      setStockUpdates({
        ...stockUpdates,
        [id]: 0,
      })

      toast({
        title: "Stock updated",
        description: `Stock for product has been updated successfully.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update stock. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search products..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>SKU</TableHead>
              <TableHead className="text-right">Current Stock</TableHead>
              <TableHead>Update Stock</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProducts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">
                  No products found.
                </TableCell>
              </TableRow>
            ) : (
              filteredProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{product.sku}</TableCell>
                  <TableCell className="text-right">
                    <Badge
                      variant={
                        product.stock > product.minStockLevel
                          ? "default"
                          : product.stock > 0
                            ? "outline"
                            : "destructive"
                      }
                    >
                      {product.stock}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        value={stockUpdates[product.id] || ""}
                        onChange={(e) => handleStockChange(product.id, e.target.value)}
                        placeholder="Enter quantity"
                        className="w-24"
                      />
                      <span className="text-sm text-muted-foreground">(+ to add, - to remove)</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      onClick={() => handleUpdateStock(product.id, product.stock)}
                      disabled={!stockUpdates[product.id]}
                    >
                      Update
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
