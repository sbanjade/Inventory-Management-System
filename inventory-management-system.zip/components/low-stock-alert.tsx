import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { AlertTriangle } from "lucide-react"

interface LowStockItem {
  id: string
  name: string
  currentStock: number
  minStockLevel: number
}

interface LowStockAlertProps {
  items: LowStockItem[]
}

export function LowStockAlert({ items }: LowStockAlertProps) {
  return (
    <Card className="col-span-3">
      <CardHeader className="flex flex-row items-center">
        <div className="grid gap-1">
          <CardTitle>Low Stock Alert</CardTitle>
        </div>
        <AlertTriangle className="ml-auto h-5 w-5 text-amber-500" />
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>Current Stock</TableHead>
              <TableHead>Min Level</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.name}</TableCell>
                <TableCell className="text-red-500">{item.currentStock}</TableCell>
                <TableCell>{item.minStockLevel}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="outline" asChild>
                    <a href={`/stock?productId=${item.id}`}>Restock</a>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
