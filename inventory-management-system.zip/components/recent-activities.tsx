import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface Activity {
  id: string
  type: "add" | "update" | "remove"
  productName: string
  quantity: number
  timestamp: string
  user: string
}

interface RecentActivitiesProps {
  activities: Activity[]
}

export function RecentActivities({ activities }: RecentActivitiesProps) {
  return (
    <Card className="col-span-4">
      <CardHeader>
        <CardTitle>Recent Activities</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Action</TableHead>
              <TableHead>Product</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>User</TableHead>
              <TableHead className="text-right">Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map((activity) => (
              <TableRow key={activity.id}>
                <TableCell>
                  <Badge
                    variant={
                      activity.type === "add" ? "default" : activity.type === "update" ? "outline" : "destructive"
                    }
                  >
                    {activity.type === "add" ? "Added" : activity.type === "update" ? "Updated" : "Removed"}
                  </Badge>
                </TableCell>
                <TableCell className="font-medium">{activity.productName}</TableCell>
                <TableCell>{activity.quantity}</TableCell>
                <TableCell>{activity.user}</TableCell>
                <TableCell className="text-right">{activity.timestamp}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
